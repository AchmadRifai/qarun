NativeX Android SDK
===============




Get started integrating with our [Android SDK integration guide](https://help.nativex.com/pages/viewpage.action?pageId=10518548)