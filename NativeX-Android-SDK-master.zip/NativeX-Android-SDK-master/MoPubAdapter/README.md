To use the NativeX Android MoPub Adapter, please reference the implementation instructions here: https://help.nativex.com/display/revenue/MoPub+NativeX+Android+Adapter+Implementation+Guide
